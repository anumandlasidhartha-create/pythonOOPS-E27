class dog:
    def sound(self):
        print("dog sound")
    def eat(sef):
        print("dog eat")
class cat(dog):
    def sound(self):
        print("cat sound")
c=cat()
c.sound()
d=dog()
d.sound()